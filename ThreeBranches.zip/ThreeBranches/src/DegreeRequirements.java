//We've introduced a DegreeProgram class that represents a degree program and its required courses.
//Each DegreeProgram object has a name and a list of required courses.
//The compileAllCourses method compiles all courses from different degree programs into a unified list.
//The initializeDegreePrograms method creates and initializes DegreeProgram objects for different branches and adds them to the degreePrograms map.
//When the user enters a Major path, the program looks up the corresponding DegreeProgram object and displays the required courses for that program.
//If the Major path is not found, it provides an error message.
//The code I provided does not include a traditional external database management system (e.g., MySQL, PostgreSQL, SQLite) because it uses in-memory data structures like HashMap and ArrayList to store and manage the data.
//However, in this context, the degreePrograms map serves as a simple database for storing degree program information and their associated courses.

import java.util.*;

class Course {
    private String name;
    private String branch;

    public Course(String name, String branch) {
        this.name = name;
        this.branch = branch;
    }

    public String getName() {
        return name;
    }

    public String getBranch() {
        return branch;
    }
}

class DegreeProgram {
    private String name;
    private List<Course> requiredCourses;

    public DegreeProgram(String name) {
        this.name = name;
        this.requiredCourses = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public List<Course> getRequiredCourses() {
        return requiredCourses;
    }

    public void addRequiredCourse(Course course) {
        requiredCourses.add(course);
    }
}

public class DegreeRequirements {
    private static Map<String, DegreeProgram> degreePrograms = new HashMap<>();

    public static void main(String[] args) {
        initializeDegreePrograms();

        // Compile all courses into a unified database
        List<Course> allCourses = compileAllCourses();

        // Create a database of courses based on the user's inputted Major path
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your Major path (e.g., Bachelor of Science, School of Music, School of Business): ");
        String majorPath = scanner.nextLine();

        DegreeProgram selectedProgram = degreePrograms.get(majorPath);

        if (selectedProgram != null) {
            List<Course> requiredCourses = selectedProgram.getRequiredCourses();

            // Display the required courses for the selected Major path
            System.out.println("Required courses for " + majorPath + ":");
            for (Course course : requiredCourses) {
                System.out.println(course.getName());
            }
        } else {
            System.out.println("Major path not found.");
        }
    }

    private static List<Course> compileAllCourses() {
        List<Course> allCourses = new ArrayList<>();
        for (DegreeProgram program : degreePrograms.values()) {
            allCourses.addAll(program.getRequiredCourses());
        }
        return allCourses;
    }

    private static void initializeDegreePrograms() {
        // Create and initialize DegreeProgram objects for different branches
        DegreeProgram scienceProgram = new DegreeProgram("Bachelor of Science");
        scienceProgram.addRequiredCourse(new Course("Biology 101", "Bachelor of Science"));
        scienceProgram.addRequiredCourse(new Course("Chemistry 101", "Bachelor of Science"));
        degreePrograms.put("Bachelor of Science", scienceProgram);

        DegreeProgram musicProgram = new DegreeProgram("School of Music");
        musicProgram.addRequiredCourse(new Course("Music Theory 101", "School of Music"));
        degreePrograms.put("School of Music", musicProgram);

        DegreeProgram businessProgram = new DegreeProgram("School of Business");
        businessProgram.addRequiredCourse(new Course("Business Ethics", "School of Business"));
        degreePrograms.put("School of Business", businessProgram);

        // Add more DegreePrograms and required courses as needed
    }
}
